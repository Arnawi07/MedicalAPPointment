package app.myapp.view;

public class Scenes {
    public static final int LOGIN = 0;
    public static final int REGISTER = 1;
    public static final int POLITICA_PRIVACIDAD = 2;
    public static final int CONDICIONES_USO = 3;
    public static final int RECUPERAR_CONTRASENA = 4;
    public static final int HOME = 5;
    public static final int NOT_FOUND = 6;

}
