package app.myapp.view;

import java.io.IOException;
import java.util.ArrayList;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 * Class SceneManager is for managing different scene of game.
 * @author kevingok
 *
 */
public class SceneManager {
    private static SceneManager instance = null;
    private int currentLevel;
    private ArrayList<Scene> scenes;
    private static Stage primaryStage = null;


    /**
     * Get instance of SceneManager
     * @return        Instance of SceneManager
     */
    public static SceneManager getInstance() throws IOException {
        if(instance == null) {
            instance = new SceneManager();
        }

        return instance;
    }


    /**
     * Class constructor initiates all scene in an ArrayList and
     * sets initial scene as menu.
     */
    private SceneManager() throws IOException {
        Parent loginViewParent = FXMLLoader.load(getClass().getResource("logIn.fxml"));
        Parent registerViewParent = FXMLLoader.load(getClass().getResource("signUp.fxml"));
        Parent politicaPrivacidadViewParent = FXMLLoader.load(getClass().getResource("politicasPrivacidad.fxml"));
        Parent condicionesUsoViewParent = FXMLLoader.load(getClass().getResource("condicionesUso.fxml"));
        Parent recuperarContrasenaViewParent = FXMLLoader.load(getClass().getResource("recuperarContrasena.fxml"));
        Parent homeViewParent = FXMLLoader.load(getClass().getResource("home.fxml"));
        Parent notFoundViewParent = FXMLLoader.load(getClass().getResource("notFound.fxml"));

        scenes = new ArrayList<>();

        scenes.add(new Scene(loginViewParent, 1200, 720));
        scenes.add(new Scene(registerViewParent, 1200, 720));
        scenes.add(new Scene(politicaPrivacidadViewParent, 1200, 720));
        scenes.add(new Scene(condicionesUsoViewParent, 1200, 720));
        scenes.add(new Scene(recuperarContrasenaViewParent, 1200, 720));
        scenes.add(new Scene(homeViewParent, 1200, 720));
        scenes.add(new Scene(notFoundViewParent, 1200, 720));
    }

    public void setStage(Stage stage){
        this.primaryStage = stage;
    }


    /**
     * Change scene of game.
     * @param sceneLevel      Type of scene as integer
     */
    public void changeSceneLevel(int sceneLevel) {
        currentLevel = sceneLevel;
        primaryStage.setScene(scenes.get(sceneLevel));
        primaryStage.setTitle("MedicalAPPointment");

        primaryStage.requestFocus();
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/img/medico.png")));
        primaryStage.show();
    }

    /**
     * Retrieve current type of scene.
     * @return           Type of scene as integer
     */
    public Scene getCurrentScene() {
        return scenes.get(currentLevel);
    }
}