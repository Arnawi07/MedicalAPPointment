package app.myapp.view.controller;

import app.myapp.view.SceneManager;
import app.myapp.view.Scenes;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Side;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignUpController{
    private SceneManager sceneManager = null;
    @FXML private Hyperlink linkCuenta;
    @FXML private Hyperlink linkCondiciones;
    @FXML private Hyperlink linkPoliticas;
    @FXML private Button btnRegistrarse;
    @FXML private TextField user;
    @FXML private TextField mail;
    @FXML private PasswordField passwd;
    @FXML private PasswordField passwdConfirmation;
    @FXML private CheckBox checkConditions;
    @FXML private ContextMenu contextMenu, contextMenu2, contextMenu3, contextMenu4;

    @FXML
    public void pressHyperLinkIrALogIn(ActionEvent event) throws IOException {
        ImageView imageViewErrorUser = null;
        ImageView imageViewErrorMail = null;
        ImageView imageViewErrorPasswd = null;
        ImageView imageViewErrorPasswdConfirmation = null;

        try{
            imageViewErrorUser = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorUser");
            imageViewErrorMail = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorMail");
            imageViewErrorPasswd = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorPasswd");
            imageViewErrorPasswdConfirmation = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorPasswd2");

            imageViewErrorUser.setVisible(false);
            imageViewErrorMail.setVisible(false);
            imageViewErrorPasswd.setVisible(false);
            imageViewErrorPasswdConfirmation.setVisible(false);
        }catch (NullPointerException ex){
            System.out.println("Si salta excepción, representa que no hay ImageView");
        }

        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.LOGIN);
    }

    @FXML
    public void pressHyperLinkIrCondicionesUso(ActionEvent event) throws IOException {
        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.CONDICIONES_USO);
    }

    @FXML
    public void pressHyperLinkIrPoliticaPrivacidad(ActionEvent event) throws IOException {
        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.POLITICA_PRIVACIDAD);
    }

    @FXML
    public void pressButtonRegistrarse(ActionEvent event) throws IOException {
        sceneManager = SceneManager.getInstance();

        String userStr, mailStr, passwdStr, passwdConfirmationStr;
        userStr = user.getText();
        mailStr = mail.getText();
        passwdStr = passwd.getText();
        passwdConfirmationStr = passwdConfirmation.getText();

        Image imageError = new Image(getClass().getResourceAsStream("/img/error.png"));

        ImageView imageViewErrorUser = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorUser");
        imageViewErrorUser.setImage(imageError);
        ImageView imageViewErrorMail = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorMail");
        imageViewErrorMail.setImage(imageError);
        ImageView imageViewErrorPasswd = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorPasswd");
        imageViewErrorPasswd.setImage(imageError);
        ImageView imageViewErrorPasswdConfirmation = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorPasswd2");
        imageViewErrorPasswdConfirmation.setImage(imageError);

        if (!userStr.isEmpty() && !mailStr.isEmpty() && !passwdStr.isEmpty() && !passwdConfirmationStr.isEmpty()){
            String regexEmail = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";

            imageViewErrorUser.setVisible(false);
            contextMenu.hide();
            imageViewErrorMail.setVisible(false);
            contextMenu2.hide();
            imageViewErrorPasswd.setVisible(false);
            contextMenu3.hide();
            imageViewErrorPasswdConfirmation.setVisible(false);
            contextMenu4.hide();

            Pattern pattern = Pattern.compile(regexEmail);
            Matcher matcher = pattern.matcher(mail.getText());

            if (!matcher.matches()){
                imageViewErrorMail.setVisible(true);
                contextMenu2.getItems().clear();
                contextMenu2.getItems().add(new MenuItem("Email invalido"));
                contextMenu2.show(mail, Side.RIGHT, 10, 0);
//                Alert alert = new Alert(Alert.AlertType.WARNING);
//                alert.setTitle("Aviso");
//                alert.setHeaderText(null);
//                alert.setContentText("Email invalido!");
//
//                alert.showAndWait();
            }
            if (!passwdStr.equals(passwdConfirmationStr)){
                imageViewErrorPasswd.setVisible(true);
                imageViewErrorPasswdConfirmation.setVisible(true);
                contextMenu3.getItems().clear();
                contextMenu3.getItems().add(new MenuItem("La contraseña de confirmación no coincide"));
                contextMenu3.show(passwd, Side.RIGHT, 10, 0);
//                Alert alert = new Alert(Alert.AlertType.WARNING);
//                alert.setTitle("Aviso");
//                alert.setHeaderText(null);
//                alert.setContentText("La contraseña de confirmación no coincide!");
//
//                alert.showAndWait();
            }else if (!checkConditions.isSelected()){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText(null);
                alert.setContentText("No has aceptado las condiciones de uso y politicas de privacidad!");

                alert.showAndWait();
            }else {
                imageViewErrorUser.setVisible(false);
                contextMenu.hide();
                imageViewErrorMail.setVisible(false);
                contextMenu2.hide();
                imageViewErrorPasswd.setVisible(false);
                contextMenu3.hide();
                imageViewErrorPasswdConfirmation.setVisible(false);
                contextMenu4.hide();

                sceneManager = SceneManager.getInstance();
                sceneManager.changeSceneLevel(Scenes.HOME);
            }
        }else{
            imageViewErrorUser.setVisible(false);
            contextMenu.hide();
            imageViewErrorMail.setVisible(false);
            contextMenu2.hide();
            imageViewErrorPasswd.setVisible(false);
            contextMenu3.hide();
            imageViewErrorPasswdConfirmation.setVisible(false);
            contextMenu4.hide();
            if (userStr.isEmpty()){
                imageViewErrorUser.setVisible(true);
                contextMenu.getItems().clear();
                contextMenu.getItems().add(new MenuItem("Falta rellenar el campo"));
                contextMenu.show(user, Side.RIGHT, 10, 0);
            }
            if (mailStr.isEmpty()){
                imageViewErrorMail.setVisible(true);
                contextMenu2.getItems().clear();
                contextMenu2.getItems().add(new MenuItem("Falta rellenar el campo"));
                contextMenu2.show(mail, Side.RIGHT, 10, 0);

            }
            if (passwdStr.isEmpty()){
                imageViewErrorPasswd.setVisible(true);
                contextMenu3.getItems().clear();
                contextMenu3.getItems().add(new MenuItem("Falta rellenar el campo"));
                contextMenu3.show(passwd, Side.RIGHT, 10, 0);

            }
            if (passwdConfirmationStr.isEmpty()){
                imageViewErrorPasswdConfirmation.setVisible(true);
                contextMenu4.getItems().clear();
                contextMenu4.getItems().add(new MenuItem("Falta rellenar el campo"));
                contextMenu4.show(passwdConfirmation, Side.RIGHT, 15, 0);
            }
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.setTitle("Aviso");
//            alert.setHeaderText(null);
//            alert.setContentText("Debes de registrarte rellenando todos los campos!");
//
//            alert.showAndWait();
        }
    }
}

