package app.myapp.view.controller;

import app.myapp.view.SceneManager;
import app.myapp.view.Scenes;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class CondicionesUsoController {
    private SceneManager sceneManager = null;

    @FXML private Button btnVolver;

    @FXML
    public void pressBtnVolver() throws IOException {
        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.REGISTER);
    }
}
