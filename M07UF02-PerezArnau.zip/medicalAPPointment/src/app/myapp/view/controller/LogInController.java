package app.myapp.view.controller;

import app.myapp.view.SceneManager;
import app.myapp.view.Scenes;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Side;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;

public class LogInController {
    private SceneManager sceneManager = null;
    @FXML private Hyperlink linkRegistrarse;
    @FXML private Hyperlink linkContraseñaOlvidada;
    @FXML private Button btnEntrar;
    @FXML private TextField user;
    @FXML private PasswordField passwd;
    @FXML private CheckBox recordarme;
    //@FXML private ImageView imgErrorUser;
    //@FXML private ImageView imgErrorPasswd;
    @FXML private MenuItem menuItem, menuItem2;
    @FXML private ContextMenu contextMenu, contextMenu2;



    @FXML
    public void pressHyperLinkRegistrarse(ActionEvent event) throws IOException {
        ImageView imageViewErrorUser = null, imageViewErrorPasswd = null;
        try {
            imageViewErrorUser = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorUser");
            imageViewErrorPasswd = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorPasswd");
            imageViewErrorUser.setVisible(false);
            imageViewErrorPasswd.setVisible(false);
        }catch (NullPointerException ex){
            System.out.println("Si salta excepción, representa que no hay ImageView");
        }
        contextMenu.hide();
        contextMenu2.hide();

        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.REGISTER);
    }

    @FXML
    public void pressHyperLinkRecuperarContraseña(ActionEvent event) throws IOException {
        ImageView imageViewErrorUser = null, imageViewErrorPasswd = null;
        try {
            imageViewErrorUser = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorUser");
            imageViewErrorPasswd = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorPasswd");
            imageViewErrorUser.setVisible(false);
            imageViewErrorPasswd.setVisible(false);
        }catch (NullPointerException ex){
            System.out.println("Si salta excepción, representa que no hay ImageView");
        }
        contextMenu.hide();
        contextMenu2.hide();

        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.RECUPERAR_CONTRASENA);
    }

    @FXML
    public void pressButtonEntrar(ActionEvent event) throws IOException {
        sceneManager = SceneManager.getInstance();

        Image imageError = new Image(getClass().getResourceAsStream("/img/error.png"));

        ImageView imageViewErrorUser = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorUser");
        imageViewErrorUser.setImage(imageError);

        ImageView imageViewErrorPasswd = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorPasswd");
        imageViewErrorPasswd.setImage(imageError);


        if (!user.getText().isEmpty() && !passwd.getText().isEmpty()){
            imageViewErrorUser.setVisible(false);
            imageViewErrorPasswd.setVisible(false);
            contextMenu.hide();
            contextMenu2.hide();

            if (!recordarme.isSelected()){
                user.setText("");
                passwd.setText("");
            }

            sceneManager.changeSceneLevel(Scenes.HOME);
        }else{
            if (user.getText().isEmpty()) {
                imageViewErrorUser.setVisible(true);
                contextMenu.show(user, Side.RIGHT, 10, 0);
            }else{
                imageViewErrorUser.setVisible(false);
                contextMenu.hide();
            }
            if (passwd.getText().isEmpty()) {
                imageViewErrorPasswd.setVisible(true);
                contextMenu2.show(passwd, Side.RIGHT, 10, 0);

            }else{
                imageViewErrorPasswd.setVisible(false);
                contextMenu2.hide();
            }

//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.setTitle("Aviso");
//            alert.setHeaderText(null);
//            alert.setContentText("Debes de iniciar sesión rellenando los campos!");
//
//            alert.showAndWait();
        }
    }
}

