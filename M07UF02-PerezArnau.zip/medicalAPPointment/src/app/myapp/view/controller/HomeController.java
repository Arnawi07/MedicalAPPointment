package app.myapp.view.controller;

import app.myapp.view.SceneManager;
import app.myapp.view.Scenes;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerBasicCloseTransition;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class HomeController implements Initializable {
    private SceneManager sceneManager = null;

    @FXML private TextField campoBuscar;
    @FXML private JFXHamburger hamburguer;
    @FXML private Button btnSalir;
    @FXML private JFXDrawer drawer;
    @FXML private Label titleCalendar;
    @FXML private TextArea events;

    @Override
    public void initialize(URL url, ResourceBundle rb){
        VBox vBox = null;
        try {
            vBox = FXMLLoader.load(getClass().getResource("../drawerContent.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        drawer.setSidePane(vBox);

        for(Node node: vBox.getChildren()){
            if (node.getAccessibleText()!=null){

                node.addEventHandler(MouseEvent.MOUSE_CLICKED, (e)->{
                    switch (node.getAccessibleText()){
                        case "inicio":
                            try {
                                sceneManager=SceneManager.getInstance();
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            titleCalendar.setText("Calendario de Sr. Benito Camela");
                            events.setText("· Evento 1\n\n· Evento 2\n\n· Evento 3\n\n· Evento 4");
                            ImageView imageViewCalendar = (ImageView) sceneManager.getCurrentScene().lookup("#imgCalendar");
                            imageViewCalendar.setImage(new Image(getClass().getResourceAsStream("/img/calendar.png")));
                            break;

                        case "otherCalendars":
                            try {
                                sceneManager=SceneManager.getInstance();
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            titleCalendar.setText("Calendario de Sra. Eusebia Tetas Planas");
                            events.setText("· Evento 1\n\n· Evento 2");
                            ImageView imageViewCalendar2 = (ImageView) sceneManager.getCurrentScene().lookup("#imgCalendar");
                            imageViewCalendar2.setImage(new Image(getClass().getResourceAsStream("/img/calendar2.png")));
                            break;

                        default:
                            break;
                    }
                });
            }
        }

        HamburgerBasicCloseTransition transition = new HamburgerBasicCloseTransition(hamburguer);
        transition.setRate(-1);
        hamburguer.addEventFilter(MouseEvent.MOUSE_CLICKED, (event) -> {
            transition.setRate(transition.getRate()*-1);
            transition.play();

            if (drawer.isOpened()){
                drawer.close();
            }else{
                drawer.open();
            }
        });
    }

    @FXML
    public void exit(ActionEvent event) throws IOException {
        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.LOGIN);
    }

    @FXML
    public void busqueda(ActionEvent event) throws IOException {
        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.NOT_FOUND);
    }
}
