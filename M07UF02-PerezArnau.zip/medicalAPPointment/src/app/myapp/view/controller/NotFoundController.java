package app.myapp.view.controller;

import app.myapp.view.SceneManager;
import app.myapp.view.Scenes;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class NotFoundController {
    private SceneManager sceneManager = null;

    @FXML private Button btnVolver;

    @FXML
    public void pressBtnVolver(ActionEvent event) throws IOException {
        sceneManager = SceneManager.getInstance();

        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.HOME);
    }
}
