package app.myapp.view.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

import java.io.IOException;

public class DrawerContent {
    @FXML
    private Button inicio, otherCalendars;

    @FXML
    public void changeBgColor(ActionEvent event) throws IOException {
        otherCalendars.setStyle("-fx-background-color: #606368;");
        inicio.setStyle("-fx-background-color: #5AC3D4;");
    }

    @FXML
    public void changeBgColor2(ActionEvent event) throws IOException {
        inicio.setStyle("-fx-background-color:  #606368;");
        otherCalendars.setStyle("-fx-background-color: #5AC3D4;");
    }

}
