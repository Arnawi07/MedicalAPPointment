package app.myapp.view.controller;

import app.myapp.view.SceneManager;
import app.myapp.view.Scenes;
import javafx.fxml.FXML;
import javafx.geometry.Side;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RecuperarContrasenaController {
    private SceneManager sceneManager = null;

    @FXML private TextArea txtArea;
    @FXML private TextField mail;
    //    @FXML private ImageView imgErrorMail;
    @FXML private MenuItem menuItem;
    @FXML private ContextMenu contextMenu;

    @FXML public void pressBtnEnviar() throws IOException {
        sceneManager = SceneManager.getInstance();
        Image imageError = new Image(getClass().getResourceAsStream("/img/error.png"));
        ImageView imageViewErrorEmail = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorMail");
        imageViewErrorEmail.setImage(imageError);

        if (!mail.getText().isEmpty()) {
            String regexEmail = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";

            Pattern pattern = Pattern.compile(regexEmail);
            Matcher matcher = pattern.matcher(mail.getText());

            if (!matcher.matches()){
                imageViewErrorEmail.setVisible(true);
                menuItem.setText("Email invalido");
                contextMenu.show(mail, Side.RIGHT, 10, 0);

//                Alert alert = new Alert(Alert.AlertType.WARNING);
//                alert.setTitle("Aviso");
//                alert.setHeaderText(null);
//                alert.setContentText("Email invalido!");
//
//                alert.showAndWait();
            }else{
                imageViewErrorEmail.setVisible(false);
                contextMenu.hide();
                txtArea.setText("Se le ha enviado el correo de recuperación de contraseña\ncorrectamente.");
            }

        }else{
            imageViewErrorEmail.setVisible(true);
            menuItem.setText("Falta rellenar campo");
            contextMenu.show(mail, Side.RIGHT, 10, 0);

//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.setTitle("Aviso");
//            alert.setHeaderText(null);
//            alert.setContentText("Debes de indicar el correo electronico!");
//
//            alert.showAndWait();
        }
    }

    @FXML public void pressBtnVolver() throws IOException {
        ImageView imageViewErrorEmail = null;
        try {
            imageViewErrorEmail = (ImageView) sceneManager.getCurrentScene().lookup("#imgErrorMail");
            imageViewErrorEmail.setVisible(false);
        }catch (NullPointerException ex){
            System.out.println("Si salta excepción, representa que no hay ImageView");
        }

        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.LOGIN);
    }
}
