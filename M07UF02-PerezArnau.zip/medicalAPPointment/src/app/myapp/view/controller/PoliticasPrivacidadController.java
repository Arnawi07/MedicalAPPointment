package app.myapp.view.controller;

import app.myapp.view.SceneManager;
import app.myapp.view.Scenes;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class PoliticasPrivacidadController {
    private SceneManager sceneManager = null;

    @FXML public Button btnVolver;

    @FXML
    public void pressBtnVolver() throws IOException {
        sceneManager = SceneManager.getInstance();
        sceneManager.changeSceneLevel(Scenes.REGISTER);
    }
}
