package app.myapp;

import app.myapp.view.SceneManager;
import javafx.application.Application;
import javafx.stage.Stage;
import app.myapp.view.Scenes;

public class Main extends Application {
    private static SceneManager sceneManager = null;

    @Override
    public void start(Stage primaryStage) throws Exception{
        sceneManager = SceneManager.getInstance();
        sceneManager.setStage(primaryStage);

        sceneManager.changeSceneLevel(Scenes.LOGIN);
    }


    public static void main(String[] args) {
        launch(args);
    }
}